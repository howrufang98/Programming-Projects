//This simulation program is to calculate the total estimated fuel consumption of the bus.
//Programmer :How Ru Fang	                1161101072
//            Nur Imanina binti Zulkarnain	1161102566
//            Flora Ang Hui Ling	        1161102508
//            Tan Kai Chong	                1161101298

#include <iostream>

using namespace std;

int main()
{
double Estimated_BusFuelConsumption (float distance_travelled, double fuel_consumption);
char response;
float selection;
float departing_busstation,destination_busstation;
float average_speed;
double fuel_consumption;
float distance_travelled;
double estimated_busfuelconsumption;
double rate;


tryagain:
cout<<"         =======================================================================\n";
cout<<"         =                           Welcome to                                =\n";
cout<<"         =                   Bus Fuel Consumption Simulator                    =\n";
cout<<"         =                                                                     =\n";
cout<<"         =                   1. Start Simulation                               =\n";
cout<<"         =                   2. Exit                                           =\n";
cout<<"         =======================================================================\n";

cout<<"\n\nPlease Choose A Function 1 or 2 and press Enter: ";
cin>>selection;
cout<<"\n\n";
if (selection==2)
return(0);

else if(selection==1){
 cout<<"        =======================================================================\n";
 cout<<"        =         1.KL Sentral                   - Kuala Lumpur               =\n";
 cout<<"        =         2.Melaka Sentral               - Melaka                     =\n";
 cout<<"        =         3.Larkin Sentral               - Johor Bahru                =\n";
 cout<<"        =         4.Changlun Bus Station         - Kedah                      =\n";
 cout<<"        =         5.Kuala Kangsar Bus Terminal   - Perak                      =\n";
 cout<<"        =         6.Kuantan Sentral              - Pahang                     =\n";
 cout<<"        =======================================================================\n";
 cout<<"        \n\n";

 cout<<"\n";
 cout<<"Please Choose Your Departing Bus Station: ";
 cin>>departing_busstation;
}
 if(departing_busstation==1){
 cout<<" KL Sentral";

 }else if(departing_busstation==2){
 cout<<" Melaka Sentral ";

 }else if(departing_busstation==3){
 cout<<" Larkin Sentral";

 }else if(departing_busstation==4){
 cout<<" Changlun Bus Station";

 }else if(departing_busstation==5){
 cout<<" Kuala Kangsar Bus Terminal";

 }else if(departing_busstation==6){
 cout<<"Kuantan Sentral";

 }else{
cout<<"\nChoice is not valid. The choice is either1/2/3/4/5/6\n";
cout<<"\nPlease Choose Your Departing Bus Station: ";
cin>>departing_busstation;

if(departing_busstation==1){
 cout<<" KL Sentral";

 }else if(departing_busstation==2){
 cout<<" Melaka Sentral ";

 }else if(departing_busstation==3){
 cout<<" Larkin Sentral";

 }else if(departing_busstation==4){
 cout<<" Changlun Bus Station";

 }else if(departing_busstation==5){
 cout<<" Kuala Kangsar Bus Terminal";

 }else if(departing_busstation==6){
 cout<<" Kuantan Sentral";}

 }

 cout<<"\n\nPlease Choose Your Destination Bus Station: ";
 cin>>destination_busstation;

 if(destination_busstation==1){
 cout<<"KL Sentral\n";

 }else if(destination_busstation==2){
 cout<<"Melaka Sentral\n ";

 }else if(destination_busstation==3){
 cout<<"Larkin Sentral\n";

 }else if(destination_busstation==4){
 cout<<"Changlun Bus Station\n";

 }else if(destination_busstation==5){
 cout<<"Kuala Kangsar Bus Terminal\n";

 }else if(destination_busstation==6){
 cout<<"Kuantan Sentral\n";

 }else{
cout<<"\nChoice is not valid. The choice is either1/2/3/4/5/6\n";
cout<<"\nPlease Choose Your Destination Bus Station: ";
cin>>destination_busstation;

 if(destination_busstation==1){
 cout<<"KL Sentral\n";

 }else if(destination_busstation==2){
 cout<<"Melaka Sentral\n ";

 }else if(destination_busstation==3){
 cout<<"Larkin Sentral\n";

 }else if(destination_busstation==4){
 cout<<"Changlun Bus Station\n";

 }else if(destination_busstation==5){
 cout<<"Kuala Kangsar Bus Terminal\n";

 }else if(destination_busstation==6){
 cout<<"Kuantan Sentral\n";
 }
 }

 cout<<"\n\n";
 cout<<"=======================================================================\n";

if(departing_busstation==1){
 cout<<"\nDeparture:KL Sentral\n";

 }else if(departing_busstation==2){
 cout<<"\nDeparture:Melaka Sentral\n ";

 }else if(departing_busstation==3){
 cout<<"\nDeparture:Larkin Sentral\n";

 }else if(departing_busstation==4){
 cout<<"\nDeparture:Changlun Bus Station\n";

 }else if(departing_busstation==5){
 cout<<"\nDeparture:Kuala Kangsar Bus Terminal\n";

 }else if(departing_busstation==6){
 cout<<"\nDeparture:Kuantan Sentral\n";
 }

if(destination_busstation==1){
 cout<<"\nDestination:KL Sentral\n";

 }else if(destination_busstation==2){
 cout<<"\nDestination:Melaka Sentral\n ";

 }else if(destination_busstation==3){
 cout<<"\nDestination:Larkin Sentral\n";

 }else if(destination_busstation==4){
 cout<<"\nDestination:Changlun Bus Station\n";

 }else if(destination_busstation==5){
 cout<<"\nDestination:Kuala Kangsar Bus Terminal\n";

 }else if(destination_busstation==6){
 cout<<"\nDestination:Kuantan Sentral\n\n";
 }
cout<<"\n";
cout<<"=======================================================================\n\n";
cout<<"\n";
cout<<"\nPlease enter the total average speed of the bus(in km/h)";
cout<<"\n(Min=70km/h; Max=110km/h)\n";
cout<<"\n";
cout<<"Please enter the total average speed of the bus between 70km/h to 110km/h: ";
cin>>average_speed;

if((average_speed>=70)&&(average_speed<=85))
    fuel_consumption=17.7;

else if((average_speed>85)&&(average_speed<=95))
    fuel_consumption=18.8;

else if((average_speed>95)&&(average_speed<=110))
    fuel_consumption=24.8;


else{
cout<<"\nPlease try again! Enter the total average speed of the bus between 70-110:";
cin>>average_speed;
if((average_speed>=70)&&(average_speed<=85))
    fuel_consumption=17.7;

else if((average_speed>85)&&(average_speed<=95))
    fuel_consumption=18.8;

else if((average_speed>95)&&(average_speed<=110))
    fuel_consumption=24.8;
}

cout<<"\n\n";
cout<<"=======================================================================\n\n";
if(departing_busstation==1){
  cout<<"\nDeparture:KL Sentral\n";

 }else if(departing_busstation==2){
 cout<<"\nDeparture:Melaka Sentral\n ";

 }else if(departing_busstation==3){
 cout<<"\nDeparture:Larkin Sentral\n";

 }else if(departing_busstation==4){
 cout<<"\nDeparture:Changlun Bus Station\n";

 }else if(departing_busstation==5){
 cout<<"\nDeparture:Kuala Kangsar Bus Terminal\n";

 }else if(departing_busstation==6){
 cout<<"\nDeparture:Kuantan Sentral\n";
 }

 if(destination_busstation==1){
 cout<<"\nDestination:KL Sentral\n";

 }else if(destination_busstation==2){
 cout<<"\nDestination:Melaka Sentral\n ";

 }else if(destination_busstation==3){
 cout<<"\nDestination:Larkin Sentral\n";

 }else if(destination_busstation==4){
 cout<<"\nDestination:Changlun Bus Station\n";

 }else if(destination_busstation==5){
 cout<<"\nDestination:Kuala Kangsar Bus Terminal\n";

 }else if(destination_busstation==6){
 cout<<"\nDestination:Kuantan Sentral\n";
 }

 if((departing_busstation==1)&&(destination_busstation==1))
{cout<<"\nDistance_travelled:0km";
distance_travelled=0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==1)&&(destination_busstation==2))
{cout<<"\nDistance_travelled:146.3km";
distance_travelled=146.3;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==1)&&(destination_busstation==3))
{cout<<"\nDistance_travelled:330.8km";
distance_travelled=330.8;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==1)&&(destination_busstation==4))
{cout<<"\nDistance_travelled:465.4km";
distance_travelled=465.4;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litr/kme"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==1)&&(destination_busstation==5))
{cout<<"\nDistance_travelled:239.0km";
distance_travelled=239.0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==1)&&(destination_busstation==6))
{cout<<"\nDistance_travelled:246.0km";
distance_travelled=246.0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}

else if((departing_busstation==2)&&(destination_busstation==1))
{cout<<"\nDistance_travelled:146.3km";
distance_travelled=146.3;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==2)&&(destination_busstation==2))
{cout<<"\nDistance_travelled:0km";
distance_travelled=0;
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==2)&&(destination_busstation==3))
{cout<<"\nDistance_travelled:217.8km";
distance_travelled=217.8;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==2)&&(destination_busstation==4))
{cout<<"\nDistance_travelled:617.7km";
distance_travelled=617.7;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==2)&&(destination_busstation==5))
{cout<<"\nDistance_travelled:391.3km";
distance_travelled=391.3;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==2)&&(destination_busstation==6))
{cout<<"\nDistance_travelled:265.7km";
distance_travelled=265.7;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==3)&&(destination_busstation==1))
{cout<<"\nDistance_travelled:330.8km";
distance_travelled=330.8;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==3)&&(destination_busstation==2))
{cout<<"\nDistance_travelled:217.8km";
distance_travelled=217.8;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==3)&&(destination_busstation==3))
{cout<<"\nDistance_travelled:0km";
distance_travelled=0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==3)&&(destination_busstation==4))
{cout<<"\nDistance_travelled:801.0km";
distance_travelled=801.0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==3)&&(destination_busstation==5))
{cout<<"\nDistance_travelled:575.0km";
distance_travelled=575.0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==3)&&(destination_busstation==6))
{cout<<"\nDistance_travelled:323.7km";
distance_travelled=323.7;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}

else if((departing_busstation==4)&&(destination_busstation==1))
{cout<<"\nDistance_travelled:465.4km";
distance_travelled=465.4;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==4)&&(destination_busstation==2))
{cout<<"\nDistance_travelled:617.7km";
distance_travelled=617.7;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==4)&&(destination_busstation==3))
{cout<<"\nDistance_travelled:801.0km";
distance_travelled=801.0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==4)&&(destination_busstation==4))
{cout<<"\nDistance_travelled:0km";
distance_travelled=0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==4)&&(destination_busstation==5))
{cout<<"\nDistance_travelled:238.6km";
distance_travelled=238.6;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==4)&&(destination_busstation==6))
{cout<<"\nDistance_travelled:691.8km";
distance_travelled=691.8;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==5)&&(destination_busstation==1))
{cout<<"\nDistance_travelled:239.0km";
distance_travelled=239.0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==5)&&(destination_busstation==2))
{cout<<"\nDistance_travelled:391.3km";
distance_travelled=391.3;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==5)&&(destination_busstation==3))
{cout<<"\nDistance_travelled:575.0km";
distance_travelled=575.0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==5)&&(destination_busstation==4))
{cout<<"\nDistance_travelled:238.6km";
distance_travelled=238.6;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==5)&&(destination_busstation==5))
{cout<<"\nDistance_travelled:0km";
distance_travelled=0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==5)&&(destination_busstation==6))
{cout<<"\nDistance_travelled:464.6km";
distance_travelled=464.6;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==6)&&(destination_busstation==1))
{cout<<"\nDistance_travelled:246.0km";
distance_travelled=246.0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==6)&&(destination_busstation==2))
{cout<<"\nDistance_travelled:265.7km";
distance_travelled=265.7;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==6)&&(destination_busstation==3))
{cout<<"\nDistance_travelled:323.7km";
distance_travelled=323.7;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==6)&&(destination_busstation==4))
{cout<<"\nDistance_travelled:691.8km";
distance_travelled=691.8;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==6)&&(destination_busstation==5))
{cout<<"\nDistance_travelled:464.6km";
distance_travelled=464.6;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
else if((departing_busstation==6)&&(destination_busstation==6))
{cout<<"\nDistance_travelled:0km";
distance_travelled=0;
cout<<"\n";
cout<<"\nFuel consumption per distance: " << fuel_consumption<<"litre/km"<<endl;
estimated_busfuelconsumption = distance_travelled * fuel_consumption;
cout<<"\nEstimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre"<<endl;
cout<<"\n";
}
cout<<"=======================================================================\n\n";

cout<<"\n";
cout<<"\nDo you want to continue(y/n):\n";
cin>>response;

while (response == 'y' || response == 'Y')
{
    goto tryagain;
}

while (response == 'n' || response == 'N')
{
    cout<<"\nCongratulations! You have finished the simulation program.";
    cout<<"\n\nTotal Estimated Bus Fuel Consumption:" << estimated_busfuelconsumption <<"litre";
    cout<<"\n\nPlease rate our system^^(1-5):";
    cin>>rate;
    cout<<"\n\n";
    return 0;
}
}




